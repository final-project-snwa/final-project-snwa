package com.team.snwa.snwabackend.domain.wallet.entity.enums;
//코인 거래 유형
public enum CoinTransactionType {
    CHARGE, //코인충전
    SPEND, //코인사용
    ATTENDANCE_REWARD, //출석 보상

    REFUND // ✅ 결제 취소로 인한 코인 회수(차감)
}
